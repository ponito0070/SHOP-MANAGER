"use client";

import { useEffect, useState } from "react";
import { supabase } from "@/lib/supabaseClient";
import {
  Search,
  Calendar,
  Plus,
  FileText,
  Eye,
  ChevronLeft,
  ChevronRight,
  Printer,
} from "lucide-react";
import Link from "next/link";
import { generateBRPDF } from "@/lib/pdfGenerator";
import VoidConfirm from '@/components/VoidConfirm'
import OrderDetailsModal from '@/components/OrderDetailsModal'

interface Purchase {
  id: string;
  reference: string;
  total_achat: number;
  date_achat: string;
  fournisseur: string | null; // Ancienne colonne texte (garde pour compatibilité)
  supplier_id: string | null; // Nouvelle colonne UUID
  suppliers?: { nom: string } | null;
  is_void?: boolean;
}

export default function PurchasesHistoryPage() {
  const [purchases, setPurchases] = useState<Purchase[]>([]);
  const [loading, setLoading] = useState(true);

  const [startDate, setStartDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [endDate, setEndDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    fetchPurchases();
  }, [startDate, endDate]);

  const fetchPurchases = async () => {
    setLoading(true);

    // Récupérer d'abord les achats, inclure fournisseur relation si possible
    const { data: purchasesData, error: purchasesError } = await supabase
      .from("purchases")
      .select(`*, suppliers(nom)`)
      .gte("date_achat", `${startDate}T00:00:00`)
      .lte("date_achat", `${endDate}T23:59:59`)
      .order("date_achat", { ascending: false });

    if (purchasesError) {
      console.error("Erreur:", purchasesError.message);
      setLoading(false);
      return;
    }

    // purchasesData already includes suppliers(nom) when supplier_id exists
    // But some rows stored the supplier id as text in `fournisseur` while supplier_id is null.
    // Collect those and fetch names in one query.
    const possibleIds = (purchasesData || [])
      .filter((p: any) => p.supplier_id == null && typeof p.fournisseur === 'string' && /^[0-9a-fA-F-]{36}$/.test(p.fournisseur))
      .map((p: any) => p.fournisseur)
    const supplierByIdMap = new Map()
    if (possibleIds.length > 0) {
      const { data: matches } = await supabase.from('suppliers').select('id, nom').in('id', possibleIds)
      matches?.forEach((s: any) => supplierByIdMap.set(s.id, s.nom))
    }

    const enrichedPurchases = purchasesData?.map((p: any) => {
      const base = { ...p, is_void: p.is_void || false }
      if (!base.suppliers && base.fournisseur && supplierByIdMap.has(base.fournisseur)) {
        base.suppliers = { nom: supplierByIdMap.get(base.fournisseur) }
      }
      return base
    }) || [];

    setPurchases(enrichedPurchases as Purchase[]);
    setLoading(false);
  };

  const [voidOpen, setVoidOpen] = useState(false)
  const [selectedId, setSelectedId] = useState<string | null>(null)

  const handleToggleVoid = async (id: string, current: boolean) => {
    const { error } = await supabase.from('purchases').update({ is_void: !current }).eq('id', id)
    if (error) {
      console.error('Erreur mise à jour void:', error.message)
      return
    }
    await fetchPurchases()
    setVoidOpen(false)
    setSelectedId(null)
  }

  const adjustDate = (days: number) => {
    const newStart = new Date(startDate);
    newStart.setDate(newStart.getDate() + days);
    const newEnd = new Date(endDate);
    newEnd.setDate(newEnd.getDate() + days);

    setStartDate(newStart.toISOString().split("T")[0]);
    setEndDate(newEnd.toISOString().split("T")[0]);
  };

  const filteredPurchases = purchases.filter(
    (p) =>
      p.reference.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (p.suppliers?.nom &&
        p.suppliers.nom.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (p.fournisseur &&
        p.fournisseur.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  const handlePrint = async (purchaseId: string) => {
    await generateBRPDF(purchaseId, supabase, "print");
  };

  const handleView = async (purchaseId: string) => {
    await generateBRPDF(purchaseId, supabase, "view");
  };

  const [orderOpen, setOrderOpen] = useState(false)
  const [orderId, setOrderId] = useState<string | null>(null)

  return (
    <div className="space-y-6">
      {/* HEADER */}
      <div className="flex justify-between items-center bg-white dark:bg-slate-800 p-4 rounded-lg border border-gray-300 dark:border-slate-600 shadow-sm">
        <div>
          <h1 className="text-2xl font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <FileText className="text-blue-600" /> Historique des Réceptions
          </h1>
          <p className="text-sm text-gray-500 dark:text-gray-400">
            Consultez les bons de réception (BR).
          </p>
        </div>
        <Link
          href="/purchases"
          className="bg-blue-600 hover:bg-blue-700 text-white px-5 py-2.5 rounded-lg font-bold flex items-center gap-2 shadow-md transition-all active:scale-95"
        >
          <Plus size={20} /> Nouvelle Réception
        </Link>
      </div>

      {/* FILTRES */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 bg-gray-100 dark:bg-slate-900 p-4 rounded-lg border border-gray-300 dark:border-slate-600">
        {/* Période avec flèches */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold uppercase text-gray-500">
            Période
          </label>
          <div className="flex items-center gap-2">
            <button
              onClick={() => adjustDate(-1)}
              className="p-2 bg-white dark:bg-slate-800 border-2 border-gray-300 dark:border-slate-500 rounded hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
              title="Jour précédent"
            >
              <ChevronLeft
                size={20}
                className="text-gray-600 dark:text-gray-300"
              />
            </button>

            <div className="flex-1 grid grid-cols-2 gap-2">
              <div className="relative">
                <Calendar
                  size={14}
                  className="absolute left-2 top-2.5 text-gray-500"
                />
                <input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full pl-8 p-2 bg-white dark:bg-slate-800 border-2 border-gray-300 dark:border-slate-500 rounded text-sm font-medium text-gray-900 dark:text-white outline-none focus:border-blue-500"
                />
              </div>
              <div className="relative">
                <Calendar
                  size={14}
                  className="absolute left-2 top-2.5 text-gray-500"
                />
                <input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full pl-8 p-2 bg-white dark:bg-slate-800 border-2 border-gray-300 dark:border-slate-500 rounded text-sm font-medium text-gray-900 dark:text-white outline-none focus:border-blue-500"
                />
              </div>
            </div>

            <button
              onClick={() => adjustDate(1)}
              className="p-2 bg-white dark:bg-slate-800 border-2 border-gray-300 dark:border-slate-500 rounded hover:bg-gray-50 dark:hover:bg-slate-700 transition-colors"
              title="Jour suivant"
            >
              <ChevronRight
                size={20}
                className="text-gray-600 dark:text-gray-300"
              />
            </button>
          </div>
        </div>

        {/* Recherche */}
        <div className="flex flex-col gap-1">
          <label className="text-xs font-bold uppercase text-gray-500">
            Recherche
          </label>
          <div className="relative">
            <Search
              size={16}
              className="absolute left-3 top-3 text-gray-500"
            />
            <input
              type="text"
              placeholder="N° BR, Fournisseur..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-10 p-2 bg-white dark:bg-slate-800 border-2 border-gray-300 dark:border-slate-500 rounded font-medium text-gray-900 dark:text-white outline-none focus:border-blue-500 placeholder-gray-400"
            />
          </div>
        </div>
      </div>

      {/* TABLEAU */}
      <div className="bg-white dark:bg-slate-800 border border-gray-300 dark:border-slate-600 rounded-lg shadow overflow-hidden">
        <table className="w-full text-left border-collapse">
          <thead className="bg-gray-100 dark:bg-slate-900 border-b-2 border-gray-300 dark:border-slate-500">
            <tr>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider">
                Référence
              </th>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider">
                Date
              </th>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider">
                Fournisseur
              </th>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider text-right">
                Montant Total
              </th>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider text-center">
                Statut
              </th>
              <th className="p-3 text-xs font-bold uppercase text-gray-600 dark:text-gray-300 tracking-wider text-right">
                Actions
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200 dark:divide-slate-600">
            {loading ? (
              <tr>
                <td
                  colSpan={5}
                  className="p-8 text-center text-gray-500"
                >
                  Chargement...
                </td>
              </tr>
            ) : filteredPurchases.length === 0 ? (
              <tr>
                <td
                  colSpan={5}
                  className="p-8 text-center text-gray-400 italic"
                >
                  Aucune réception sur cette période.
                </td>
              </tr>
            ) : (
              filteredPurchases.map((purchase) => (
                <tr
                  key={purchase.id}
                  className={`hover:bg-blue-50 dark:hover:bg-slate-700/50 transition-colors group ${purchase.is_void ? 'opacity-60 line-through' : ''}`}
                >
                  <td className="p-3 font-mono text-sm font-bold text-blue-600 dark:text-blue-400 group-hover:underline">
                    <div className="flex items-center gap-2">
                      <button onClick={() => { setOrderId(purchase.id); setOrderOpen(true) }} className="text-left underline">{purchase.reference}</button>
                      {purchase.is_void && (
                        <span className="text-xs bg-gray-100 dark:bg-slate-700 text-gray-600 dark:text-gray-300 px-2 py-0.5 rounded">Annulé</span>
                      )}
                    </div>
                  </td>
                  <td className="p-3 text-sm text-gray-700 dark:text-gray-300">
                    {new Date(purchase.date_achat).toLocaleDateString("fr-FR")}{" "}
                    <span className="text-xs text-gray-400">
                      {new Date(
                        purchase.date_achat
                      ).toLocaleTimeString("fr-FR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </span>
                  </td>
                  <td className="p-3 text-sm font-medium text-gray-900 dark:text-white">
                    {purchase.suppliers?.nom || purchase.fournisseur || "N/A"}
                  </td>
                  <td className="p-3 text-sm font-bold text-right text-gray-900 dark:text-white tabular-nums">
                    {purchase.total_achat.toLocaleString("fr-FR", {
                      minimumFractionDigits: 2,
                      maximumFractionDigits: 2,
                    })}{" "}
                    <span className="text-xs font-normal text-gray-500">
                      DA
                    </span>
                  </td>
                  <td className="p-3 text-center">
                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase border 
                      ${purchase.is_void ? "bg-gray-100 text-gray-700 border-gray-200" : "bg-green-100 text-green-700 border-green-200"}`}>
                      {purchase.is_void ? 'annulé' : 'validé'}
                    </span>
                  </td>
                  <td className="p-3 text-right space-x-1">
                    <button
                      onClick={() => handleView(purchase.id)}
                      className="p-2 text-gray-500 hover:text-blue-600 hover:bg-blue-100 rounded transition-colors"
                      title="Voir le BR (PDF)"
                    >
                      <Eye size={18} />
                    </button>
                    <button
                      onClick={() => handlePrint(purchase.id)}
                      className="p-2 text-gray-500 hover:text-green-600 hover:bg-green-100 rounded transition-colors"
                      title="Imprimer le BR"
                    >
                      <Printer size={18} />
                    </button>
                    <button
                      onClick={() => { setSelectedId(purchase.id); setVoidOpen(true); }}
                      className="ml-3 text-sm text-red-500 hover:text-red-700 rounded transition-colors"
                      title={purchase.is_void ? "Rétablir la commande" : "Annuler la commande"}
                    >
                      {purchase.is_void ? "Rétablir la commande" : "Annuler la commande"}
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
      <VoidConfirm
        open={voidOpen}
        message="Marquer ce bon comme annulé n'inversera pas automatiquement les stocks. Confirmer ?"
        onClose={() => setVoidOpen(false)}
        confirmLabel="Annuler la commande"
        onConfirm={() => selectedId && handleToggleVoid(selectedId, purchases.find(p => p.id===selectedId)?.is_void || false)}
      />
      <OrderDetailsModal open={orderOpen} onClose={() => setOrderOpen(false)} id={orderId} type="purchase" />
    </div>
  );
}